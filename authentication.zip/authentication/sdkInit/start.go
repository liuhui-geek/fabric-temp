package sdkInit

import (
	"fmt"
	mspclient "github.com/hyperledger/fabric-sdk-go/pkg/client/msp"
	"github.com/hyperledger/fabric-sdk-go/pkg/client/resmgmt"
	"github.com/hyperledger/fabric-sdk-go/pkg/common/errors/retry"
	"github.com/hyperledger/fabric-sdk-go/pkg/common/providers/msp"
	"github.com/hyperledger/fabric-sdk-go/pkg/core/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/fabsdk"

//	"github.com/hyperledger/fabric-sdk-go/pkg/client/channel"
//	"github.com/hyperledger/fabric-sdk-go/pkg/fab/ccpackager/gopackager"
//	"github.com/hyperledger/fabric-sdk-go/third_party/github.com/hyperledger/fabric/common/policydsl"
)

const ChaincodeVersion = "1.0"

func SetupSDK(ConfigFile string , initialized bool) (*fabsdk.FabricSDK, error) {
	if initialized{
		return nil,fmt.Errorf("fabric SDK is initialized")
	}

	sdk,err := fabsdk.New(config.FromFile(ConfigFile))
	if err != nil{
		return nil,fmt.Errorf("Initialized fabric SDK failed")
	}
	return sdk,nil
}

func CreateChannel(sdk *fabsdk.FabricSDK, info *InitInfo) error  {
	//create resource management client
	clientContext := sdk.Context(fabsdk.WithUser(info.OrgAdmin),fabsdk.WithOrg(info.OrgName))
	if clientContext == nil{
		return fmt.Errorf("depend on orgAdmin and orgName to build context failed")
	}

	resMgmtClient, err := resmgmt.New(clientContext)
	if err != nil{
		return fmt.Errorf("depend on context to build resource management client failed")
	}
	//create channel management client
	mspClient ,err := mspclient.New(sdk.Context(),mspclient.WithOrg(info.OrgName))
	if err != nil{
		return fmt.Errorf("depend on orgName to create OrgMspclient failed")
	}
	adminIdentity, err := mspClient.GetSigningIdentity(info.OrgAdmin)
	if err != nil{
		return fmt.Errorf("get orgAdmin indentity failed")
	}
	channelReq := resmgmt.SaveChannelRequest{ChannelID: info.ChannelID, ChannelConfigPath: info.ChannelConfig,SigningIdentities: []msp.SigningIdentity{adminIdentity}}
	_, err = resMgmtClient.SaveChannel(channelReq,resmgmt.WithRetry(retry.DefaultResMgmtOpts),resmgmt.WithOrdererEndpoint(info.OrdererOrgName))
	if err != nil{
		return fmt.Errorf("create application channel failed"+err.Error())
	}
	fmt.Println("Create channel success!")

	info.OrgResMgmt = resMgmtClient

	//allow peer to join exitsting channel with
	err = info.OrgResMgmt.JoinChannel(info.ChannelID, resmgmt.WithRetry(retry.DefaultResMgmtOpts), resmgmt.WithOrdererEndpoint(info.OrdererOrgName))
	if err != nil{
		fmt.Errorf("peers join channel failed")
	}
	fmt.Println("peers join channel success")
	return nil
}