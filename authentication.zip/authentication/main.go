package main

import (
	"os"
	"fmt"
	"authentication/sdkInit"
)

const (
	configFile = "config.yaml"
	initialized = false
	SimpleCC = "simplecc"
)

func main()  {
	initInfo := &sdkInit.InitInfo{
		ChannelID: "institutionchannel",
		ChannelConfig: os.Getenv("GOPATH")+"/src/github.com/authentication/channel-artifacts/channel.tx",

		OrgAdmin: "Admin",
		OrgName: "Org_cnic",
		OrdererOrgName: "orderer0.institution.com",

		ChaincodeID: SimpleCC,
		ChaincodeGoPath: os.Getenv("GOPATH"),
		ChaincodePath: "github.com/authentication/chaincode/",
		UserName: "User1",
	}
	sdk , err := sdkInit.SetupSDK(configFile,initialized)
	if err != nil{
		fmt.Println(err.Error())
		return
	}
	defer sdk.Close()
	err = sdkInit.CreateChannel(sdk,initInfo)
	if err != nil{
		fmt.Println(err.Error())
		return
	}

}