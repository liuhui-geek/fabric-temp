/*
author:liuhui
 */
package sdkInit

import "github.com/hyperledger/fabric-sdk-go/pkg/client/resmgmt"

type InitInfo struct {
	//the name of channel
	ChannelID string
	//the path of channel config files
	ChannelConfig string
	//the Admin of org
	OrgAdmin string
	//the name of org
	OrgName string
	//the name of orderer
	OrdererOrgName string
	//the client of resource managerment
	OrgResMgmt *resmgmt.Client

	//the name of chaincode
	ChaincodeID string
	ChaincodeGoPath string
	ChaincodePath string
	UserName string
}
